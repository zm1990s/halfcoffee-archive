---
title: About
date: 2016-06-15 15:21:24
---

谢帅shawn
---

项目
---
* [一个简单的WebGL渲染器](https://coding.net/u/shawn0326/p/webgl-examples/git)-[demo](https://shawn0326.coding.me/webgl-examples/test)
* [egg (一个基于egret eui的极速开发框架)](https://coding.net/u/shawn0326/p/egg/git)
* [chronology (canvas历史对比年表)](https://coding.net/u/shawn0326/p/chronology/git)-[demo](https://shawn0326.coding.me/chronology)
* [tree (canvas树木生长模拟)](https://coding.net/u/shawn0326/p/tree/git)-[demo](https://shawn0326.coding.me/tree)

联系方式
---
* 邮箱：shawn0326@163.com
* 微博：[@谢帅shawn](http://weibo.com/shawn0326)
* 微信公众号：HalfLab

